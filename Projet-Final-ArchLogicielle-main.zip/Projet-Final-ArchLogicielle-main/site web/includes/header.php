<!DOCTYPE html>
<!-- -->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>ESP News - Site d'acutualité</title>
        <link rel="stylesheet" href="style.css">
        <script src="script.js"></script>
    </head>

    <body>

    <header><h1 id="titre">ESP News</h1>
        <nav>
                <ul class="navlinks">
                    <li>
                        <a class="firstA" href="index.php">A la une</a>
                    </li>
                    <li>
                        <a class="firstA" href="categorie.php?categorie=1">Sport</a>
                    </li>
                    <li>
                        <a class="firstA" href="categorie.php?categorie=2">Santé</a>
                    </li>
                    <li>
                        <a class="firstA" href="categorie.php?categorie=3">Education</a>
                    </li>
                    <li>
                        <a class="firstA" href="categorie.php?categorie=4">Politique</a>
                    </li>     
                </ul>
                <ul>
                    <li>
                        <a id="secondA" href="signin.php">Se connecter</a>
                    </li> 
                </ul>
        </nav>
    </header>  