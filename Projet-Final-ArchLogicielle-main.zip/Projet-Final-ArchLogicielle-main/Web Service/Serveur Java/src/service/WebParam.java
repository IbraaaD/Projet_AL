package service;

public @interface WebParam {

    String name();

}
