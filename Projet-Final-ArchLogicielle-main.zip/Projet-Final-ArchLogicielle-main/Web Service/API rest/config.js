const config = {
    db: {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'mglsi_news',
    },
    listPerPage: 10,
};

module.exports= config;