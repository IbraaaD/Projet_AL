<?php
include 'includes/header.php';
include 'includes/footer.php';
?>

<div class="background-image"> 
    <div class="container">
        <div class="row align-items-center" style="height:100vh !important;">
            <div class="col-4 mx-auto" style="max-width: none;">
                <div class="card" style="width: 20rem;">
                <div class="card-body">
                    <div class="form-group col-12">
                            <h5>Mot de passe oublié</h5>
                    </div>
                    <form>
                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="name">Email</label>
                                <input id="name" type="email" name="email" placeholder="Enter valid email" class="form-control">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-12">
                                <button class="btn btn-primary">Submit</button>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="name">Email</label>
                                <input id="name" type="email" name="email" placeholder="Enter valid email" class="form-control">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-12">
                                <label for="name">Email</label>
                                    Already have account? <a href="pageConnexion.php" class="bluish-text">Sign in</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
       </div>
</div>

