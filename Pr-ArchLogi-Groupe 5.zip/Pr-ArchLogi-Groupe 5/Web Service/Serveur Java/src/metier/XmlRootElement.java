package metier;

public @interface XmlRootElement {

}
